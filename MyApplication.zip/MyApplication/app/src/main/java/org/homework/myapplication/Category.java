package org.homework.myapplication;

import java.io.Serializable;

public class Category implements Serializable {

    public String Name;
    public Question[] Questions;

    public Category(String name, Question[] questions){
        Name = name;
        Questions = questions;
    }
}
