package org.homework.myapplication;

import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.bluehomestudio.luckywheel.LuckyWheel;
import com.bluehomestudio.luckywheel.OnLuckyWheelReachTheTarget;
import com.bluehomestudio.luckywheel.WheelItem;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FirstFragment extends Fragment {

    private LuckyWheel lw;
    private Random random = new Random();
    private List<WheelItem> wheelItems;
    private Button btnStart;
    private Category[] categories;
    private int selectedCategoryIndex = 0;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    private int getRandom() {
        selectedCategoryIndex = random.nextInt(categories.length);
        lw.setTarget(selectedCategoryIndex + 1);

        return selectedCategoryIndex;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        btnStart = view.findViewById(R.id.btn_start);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle b = new Bundle();

                //q.QuestionText = "In what country would you find Lake Bled?";
                b.putSerializable("category", categories[selectedCategoryIndex]);
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment, b);
            }
        });

        generateCategories();
        generateWheelItems();
        lw = view.findViewById(R.id.lwv);

        lw.addWheelItems(wheelItems);
        lw.setTarget(1);

        lw.onFinishRotation();
        lw.setEnabled(false);
        lw.setLuckyWheelReachTheTarget(new OnLuckyWheelReachTheTarget() {
            @Override
            public void onReachTarget() {
                Toast.makeText(getContext(), categories[selectedCategoryIndex].Name, Toast.LENGTH_LONG).show();
                btnStart.setEnabled(true);

                //lw.setTarget(getRandom() + 1);
            }
        });



        Button btnRotate = view.findViewById(R.id.btn_rotate);
        btnRotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnStart.setEnabled(false);
                lw.rotateWheelTo(getRandom() + 1);
            }
        });

    }

    private void generateCategories() {
        categories = new Category[]{
          new Category("Nature",
                  new Question[]{
                          new Question("What is the coldest sea on Earth?", new String[] {
                                  "White Sea",
                                  "Caspian Sea ",
                                  "Persian Gulf",
                                  "Baltic Sea"
                          }, 0),
                          new Question("What is the highest mountain in Britain?", new String[] {
                                  "Braeriach",
                                  "Ben Nevis",
                                  "Ben Lawers",
                                  "Cairn Toul"
                          }, 1) ,
                          new Question("What is the longest river?", new String[] {
                                  "River Severn",
                                  "Amazon",
                                  "Nile",
                                  "Yangtze"
                          }, 2),
                          new Question("What is the largest desert in the world?", new String[] {
                                  "Antarctica",
                                  "Sahara Desert",
                                  "Libyan Desert",
                                  "Gobi Desert"
                          }, 0),
                          new Question("In which continent is the world’s longest river, the Nile?", new String[] {
                                  "Africa",
                                  "Europe",
                                  "Antarctica",
                                  "Asia"
                          }, 0)
              }
                  ),
                new Category("Map Information",
                        new Question[]{
                                new Question("In what country would you find Lake Bled?", new String[] {
                                        "Macedonia",
                                        "Slovenia ",
                                        "Romania",
                                        "Bulgaria"
                                }, 1),
                                new Question("In which country is the worlds highest waterfall?", new String[] {
                                        "Brazil",
                                        "Colombia",
                                        "Venezuela",
                                        "Argentina"
                                }, 2) ,
                                new Question("What is Earth's largest continent?", new String[] {
                                        "Africa",
                                        "Antarctica",
                                        "Europe",
                                        "Asia"
                                }, 3),
                                new Question("What is the largest country in South America?", new String[] {
                                        "Brazil",
                                        "Argentina",
                                        "Peru",
                                        "Columbia"
                                }, 0),
                                new Question("What is the only major city located on two continents?", new String[] {
                                        "London",
                                        "Istanbul",
                                        "Rome",
                                        "New Delhi"
                                }, 1)
                        }
                ),
                new Category("Regions",
                        new Question[]{
                                new Question("What is the smallest country in the world?", new String[] {
                                        "San Marino",
                                        "Marshall Islands",
                                        "Monaco",
                                        "Vatican City"
                                }, 3),
                                new Question("Globalization has depressed wages in western industrialized countries, particularly those for ncy?", new String[] {
                                        "highly skilled workers",
                                        "highly educated workers",
                                        "semi-skilled workers",
                                        "low skilled worker"
                                }, 3) ,
                                new Question("Alberta is a province of which country?", new String[] {
                                        "Italy",
                                        "America",
                                        "Norway",
                                        "Canada"
                                }, 3),
                                new Question("What is the highest active volcano in Europe?", new String[] {
                                        "Teide",
                                        "Mount Etna",
                                        "Mount Elbrus",
                                        "Mount Pico"
                                }, 1),
                                new Question("Which of the following is a Southern Caucasus country in the CIS?", new String[] {
                                        "Kazakhstan",
                                        "Tajikistan",
                                        "Azerbaijan",
                                        "Uzbekistan"
                                }, 2)
                        }
                ),
                new Category("Capitals",
                        new Question[]{
                                new Question("What is the capital of Poland?", new String[] {
                                        "Lodz",
                                        "Katowice",
                                        "Krakow",
                                        "Warsaw"
                                }, 3),
                                new Question("What country is Beirut the capital of ?", new String[] {
                                        "Qatar",
                                        "Lebanon",
                                        "Israel",
                                        "Egypt"
                                }, 1) ,
                                new Question("What is the capital of Chile?", new String[] {
                                        "Santiago",
                                        "Valdivia",
                                        "Arica",
                                        "Concepcion"
                                }, 1),
                                new Question("What is the capital of Canada?", new String[] {
                                        "Ottawa",
                                        "Berlin",
                                        "Santiago",
                                        "Warsaw"
                                }, 0),
                                new Question("What is the capital of Russia?", new String[] {
                                        "Moscow",
                                        "Rome",
                                        "Paris",
                                        "Berlin"
                                }, 0)
                        }
                )
        };
    }

    private void generateWheelItems() {
        wheelItems = new ArrayList<>();

        wheelItems.add(new WheelItem(Color.parseColor("#fc6c6c"), BitmapFactory.decodeResource(getResources(),
                R.drawable.chat) , categories[0].Name));
        wheelItems.add(new WheelItem(Color.parseColor("#00E6FF"), BitmapFactory.decodeResource(getResources(),
                R.drawable.map) , categories[1].Name));
        wheelItems.add(new WheelItem(Color.parseColor("#F00E6F"), BitmapFactory.decodeResource(getResources(),
                R.drawable.ice_cream), categories[2].Name));
        wheelItems.add(new WheelItem(Color.parseColor("#00E6FF"), BitmapFactory.decodeResource(getResources(),
                R.drawable.lemonade), categories[3].Name));

    }
}
