package org.homework.myapplication;

import java.io.Serializable;

public class Question implements Serializable {

    public String QuestionText;
    public String[] Choices;
    public int CorrectChoiceIndex;

    public Question(String questionText, String[] choices, int correctChoiceIndex){
        QuestionText = questionText;
        Choices = choices;
        CorrectChoiceIndex = correctChoiceIndex;
    }
}
