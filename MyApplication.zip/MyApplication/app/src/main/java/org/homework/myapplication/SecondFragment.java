package org.homework.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import java.util.ArrayList;

public class SecondFragment extends Fragment {

    TextView tvQuestion;
    ArrayList<Button> choiceButtons;
    Category category;
    Question currentQuestion;

    private int questionIndex;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    private void displayCurrentQuestion(){

        currentQuestion = category.Questions[questionIndex];
        String questionText = currentQuestion.QuestionText;

        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(
                String.format("%s %d/%d", category.Name, questionIndex + 1, category.Questions.length));

        tvQuestion.setText(questionText);

        for (int i = 0; i < currentQuestion.Choices.length ; i++) {
            choiceButtons.get(i).setText(currentQuestion.Choices[i]);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(
                R.string.app_name);
    }

    private void checkAnswer(int choiceIndex) {

        if (choiceIndex == currentQuestion.CorrectChoiceIndex){

            //check if this was the last question
            if (questionIndex + 1 == category.Questions.length)
            {
                Toast.makeText(getContext(), "Congratulations!", Toast.LENGTH_SHORT).show();
                getActivity().onBackPressed();
                return;
            }

            questionIndex++;

            displayCurrentQuestion();
        }
        else{
            ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle(
                    R.string.app_name);
            getActivity().onBackPressed();
            Toast.makeText(getContext(), "Wrong!", Toast.LENGTH_SHORT).show();
        }
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvQuestion = view.findViewById(R.id.textview_question);
        Bundle b = getArguments();
        category = (Category) b.getSerializable("category");

        choiceButtons = new ArrayList<>();
        choiceButtons.add((Button)view.findViewById(R.id.button_one));
        choiceButtons.add((Button)view.findViewById(R.id.button_second));
        choiceButtons.add((Button)view.findViewById(R.id.button_third));
        choiceButtons.add((Button)view.findViewById(R.id.button_fourth));

        for (int i = 0; i < choiceButtons.size(); i++) {
            choiceButtons.get(i).setTag(i);
            choiceButtons.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int buttonIndex = (int)v.getTag();
                    checkAnswer(buttonIndex);
                }
            });
        }

        displayCurrentQuestion();

//        view.findViewById(R.id.button_second).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                NavHostFragment.findNavController(SecondFragment.this)
//                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
//
//
//            }
//        });
    }
}
